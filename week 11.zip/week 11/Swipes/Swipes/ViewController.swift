//
//  ViewController.swift
//  Swipes
//
//  Created by Jennifer Hott-Leitsch on 3/31/17.
//  Copyright © 2017 Jennifer Hott-Leitsch. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var label: UILabel!
    private var gestureStartPoint: CGPoint!
    private static let minimumGestureLength = Float(25.0)
    private static let maximimVariance = Float(5)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            gestureStartPoint = touch.location(in: self.view)
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            let currentPosition = touch.location(in: self.view)
            
            let deltax = fabsf(Float(gestureStartPoint.x - currentPosition.x))
            let deltay = fabsf(Float(gestureStartPoint.y - currentPosition.y))
            
            if deltax >= ViewController.minimumGestureLength && deltay <= ViewController.maximimVariance {
                    label.text = "Horizontal Swipe Detected"
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(2 * NSEC_PER_SEC)) / Double(NSEC_PER_SEC)) {
                        self.label.text = ""
                }
            } else if deltay >= ViewController.minimumGestureLength && deltax <= ViewController.maximimVariance {
                label.text = "Vertical Swipe Detected"
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(2 * NSEC_PER_SEC)) / Double(NSEC_PER_SEC)) {
                    self.label.text = ""
                }
            }
        }
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

